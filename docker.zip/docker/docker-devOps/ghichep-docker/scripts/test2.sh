#!/bin/bash -ex

echo "Toi la  TAM"
mkdir /root/son1
echo "Toi la  TAM" > testtext1.txt

