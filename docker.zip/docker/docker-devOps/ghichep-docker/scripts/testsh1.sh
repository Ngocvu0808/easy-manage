#!/bin/bash -ex

echo "Toi la son"
mkdir /root/son
echo "Kiem tra chuong trinh" > testtext.txt

