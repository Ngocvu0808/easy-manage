# docker-ghichep
- Những ghi chép về docker

### Lịch sử tài liệu
- 02.2015: Tạo tài liệu
- 03.2017: Update các tài liệu về dockerfile, docker volume, docker compose, docker swarm
- 09.2017: Bổ sung các tài liệu về thực hành, tái cấu trúc lại thư mục tài liệu.

### Giới thiệu ngắn 
- Tôi bắt đầu tìm hiểu Docker từ 06/2014. 
- Dừng ở mức sử dụng và vận hành.

### Vì sao lại tìm hiểu Docker
- Nên thuận theo ý đời (xu hướng công nghệ) nếu không thì tạo ra cho người khác dùng.

### Nên bắt đầu với Docker như nào
- Cơ bản, cơ bản ... cần có kiến thức cơ bản (Linux, TCP/IP, OSI)
- Chăm chỉ theo dõi thông tin và thực hành đều đặn.
- Bắt chước và tạo ra cái mới.
- Sysad, Developer nên dùng được Docker.

### Các thành viên đóng góp
- Tô Thành Công.
- Nguyễn Công Đức.
- Lê Thanh Lĩnh.
- Nguyễn Trọng Tấn.