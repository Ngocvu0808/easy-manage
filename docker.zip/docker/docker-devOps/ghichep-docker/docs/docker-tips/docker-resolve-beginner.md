# 11. Giải quyết các vấn đề về Docker như một Docker Beginner

____
____

# <a name="content">Nội dung</a>

![https://nickjanetakis.com/assets/blog/cards/docker-tips-and-tricks-56b5452dc709c8861641d9011d55ed5e6f5138b7d1e76a5e258160077c903076.jpg](https://nickjanetakis.com/assets/blog/cards/docker-tips-and-tricks-56b5452dc709c8861641d9011d55ed5e6f5138b7d1e76a5e258160077c903076.jpg)

- Khi điều chỉnh Docker với tư cách là người mới bắt đầu, thật dễ dàng bị "chết đuối" do tình trạng quá tải thông tin. Đây có thể coi là một "chiếc áo phao".

- Cố nghĩ bạn sẽ giải quyết vấn đề của bạn mà không cần Docker, sau đó nói chuyện về vấn đề này cho đến khi bạn có thể xác định rõ ràng và giải thích vấn đề cho [Rubber duck](https://en.wikipedia.org/wiki/Rubber_duck_debugging).

- Bạn không cần phải thực hiện nó mà không có Docker, nhưng nếu bạn chỉ mới bắt đầu thì có thể rất có lợi cho việc đó, chỉ để bạn biết mọi thứ đang hoạt động ở mọi cấp độ như thế nào.

- Bây giờ bạn đã sẵn sàng để thực hiện nó với Docker.

- Bạn có thể nghĩ rằng "cảm ơn đội trưởng rất rõ ràng!" , Nhưng đó là sự thật. Điều này chỉ trở lại với một kỹ thuật giải quyết vấn đề vô cùng hiệu quả liên quan đến việc [phá vỡ các vấn đề](https://nickjanetakis.com/blog/breaking-down-problems-is-the-number-1-software-developer-skill).
____

# <a name="content-others">Các nội dung khác</a>
